<!doctype html>
<html>
<head>
<title> Abhay Shukla </title> </head>
<body>
<h1> Employee logout page </h1>
<form action="" method="POST">
<button type="logout" name="logout" value="logout">LOGOUT </button>
</form>
</body>
</html>
<?php
session_start();
$output = $_SESSION['output'];
$conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
$logout_date = date("F j, Y, g:i a");
date_default_timezone_set('Asia/Kolkata');
$logout_time=date('H:ia');
if (isset($_POST['logout'])){
$sql = "UPDATE `employee_attendance` SET `logout date`='$logout_date',`logout time`='$logout_time' WHERE name ='$output'";
if(!mysqli_query($conn,$sql))
{
  echo "not updatedate";
}else {
  sleep(1);
  echo "updatedate";
  header("location:http://localhost/database/emp/login.php");

}
}
?>
