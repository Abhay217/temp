<?php
session_start();
  if(isset($_POST['image']))
  {
    $data = $_POST['data'];

    // file_put_contents($output_file, file_get_contents($data));
    function base64_to_jpeg($base64_string, $output_file) {
    // open the output file for writing
    $ifp = fopen( $output_file, 'wb' );

    // split the string on commas
    // $data[ 0 ] == "data:image/png;base64"
    // $data[ 1 ] == <actual base64 string>
    $data = explode( ',', $base64_string );

    // we could add validation here with ensuring count( $data ) > 1
    fwrite( $ifp, base64_decode( $data[ 1 ] ) );

    // clean up the file resource
    fclose( $ifp );

    return $output_file;
}


base64_to_jpeg($data,"path/h.png");
// echo "success";

// $message = exec("/opt/lampp/htdocs/open_cv/fri.py 2>&1");
// echo(exec("/usr/bin/python fri.py 2>&1"));

// print_r($message);

$command = escapeshellcmd('fri.py');
$output = shell_exec($command);
// print_r($output);
$_SESSION['output'] =$output;
$conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
$login_date = date("F j, Y, g:i a");
date_default_timezone_set('Asia/Kolkata');
$login_time=date('H:ia');
$sql ="INSERT INTO `employee_attendance`(`name`, `login date`, `login time`) VALUES ('$output', '$login_date','$login_time')";

if(!mysqli_query($conn,$sql))
{
  echo "o";
}else {
  echo "1";
  // header("location:http://localhost/database/emp/open_cv/open_cv/logout.php");
}
//
// ob_start();
// passthru('/usr/bin/python3 fri.py');
// $output = ob_get_clean();
  }
  // session_start();
  // $phone=$_SESSION['phone'];
  // $login_date = date("Y-m-d");
  // $login_time = date("H:i:s");
  // $conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
  // $sql ="SELECT `name` FROM `employee_profile` WHERE phone = '$phone'";
  // $result1 = mysqli_query($conn,$sql);
  // $row=mysqli_fetch_assoc(result);
  // $result = $row9['name'];
  // if($result == $output)
  // {
  //   $sql1 ="INSERT INTO `employee_attendance`(`name`, `login date`, `login time`) VALUES ('$result', ' $login_date','$login_time')";
  // }

  

?>
