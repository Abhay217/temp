<?php
echo "youre password is reset";
?>
<form action="login.php" method="POST">
<button name="went to login page" type="went to login page" class="btn btn-danger px-4 py-2 text-uppercase white font-small-4 box-shadow-2 border-0" value="went to login page">login page </button>
</form>