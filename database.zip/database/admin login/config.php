<<?php
$conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");
 ?>
