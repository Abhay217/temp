<?php
$con = mysqli_connect("localhost","root","","smart_attendance");
$name = $_POST['name'];
$address  = $_POST['address'];
$branch = $_POST['branch'];
$phone = $_POST['phone'];
$gender	=$_POST['gender'];
$domain =$_POST['domain'];
$work =$_POST['work'];
$dob =$_POST['dob'];
$doj =$_POST['doj'];
$aadhaar =$_POST['aadhaar'];
$pan =$_POST['pan'];
$password =$_POST['password'];
$photo =$_POST['photo'];
$email =$_POST['email'];



$sql = "INSERT INTO `employee_profile`( `name`, `gender`, `phone`, `address`, `branch`, `domain`, `work`, `dob`, `doj`, `aadhaar`, `pan`, `photo`, `password`,`email`) VALUES ('$name','$gender','$phone','$address','$branch','$domain', '$work', '$dob', '$doj', '$aadhaar', '$pan', '$photo', '$password','$email')";
if(!mysqli_query($con,$sql))
{
  echo "not inserted";
}else {
  echo "inserted";
  header("location:http://localhost/database/admin%20login/index.php");
}
if ((!empty($name)) || (!empty($Address)) || (!empty($email)) || (!empty($Phone)))
{

} else {
echo " All field are required";
die();
}
?>
