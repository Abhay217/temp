<?php
include 'header.php';
?>

<div id="main-content">
    <h2>All Records</h2>
    <?php
    $conn = mysqli_connect("localhost","root","","smart_attendance") or die("connection failed");

    $sql = "SELECT * FROM employee_profile";
    $result = mysqli_query($conn, $sql) or die("Query unsusuccessful");
    if (mysqli_num_rows($result) > 0) {
        ?>

    <table cellpadding="7px">
        <thead>
        <th>Id</th>
        <th>Name</th>
        <th>Gender</th>
        <th>Phone</th>
        <th>Address</th>
        <th>Branch</th>
        <th>Domain</th>
        <th>work</th>
        <th>DOB</th>
        <th>DOJ</th>
        <th>Aadhaar</th>
        <th>PAN</th>
        <th>PHOTO</th>
        <th>Password</th>
        <th>Email</th>


        </thead>
        <tbody>
          <?php
          while($row = mysqli_fetch_assoc($result))
          {

             ?>
          <tr>
          <tr>
              <td><?php echo $row['id']; ?></td>
              <td><?php echo $row['name']; ?></td>
              <td><?php echo $row['gender']; ?></td>
              <td><?php echo $row['phone']; ?></td>
              <td><?php echo $row['address']; ?></td>
              <td><?php echo $row['branch']; ?></td>
              <td><?php echo $row['domain']; ?></td>
              <td><?php echo $row['work']; ?></td>
              <td><?php echo $row['dob']; ?></td>
              <td><?php echo $row['doj']; ?></td>
              <td><?php echo $row['aadhaar']; ?></td>
              <td><?php echo $row['pan']; ?></td>
              <td><?php echo $row['photo']; ?></td>
              <td><?php echo $row['password']; ?></td>
              <td><?php echo $row['email']; ?></td>


              <td>
                  <a href='edit.php?id=<?php echo $row['id']; ?>'>Edit</a>
                  <a href='delete-inline.php?id=<?php echo $row['id']; ?>'>Delete</a>
              </td>
          </tr>
       <?php } ?>
      </tbody>
  </table>
<?php } ?>
</div>
</div>
</body>
</html>
